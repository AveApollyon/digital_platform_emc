import csv

from django.db.models import Count
from django.http import HttpResponse
from django.shortcuts import render, redirect
from .models import Patient, Visit, Symptom
from django.db import models


def main(request):
    return render(request, 'main/main.html')


def patient_statistics(request):
    # Статистика по пациентам
    total_patients = Patient.count_patients()
    age_groups = Patient.patients_by_age_group()
    gender_distribution = Patient.count_patients_by_gender()

    # Статистика по посещениям
    visits_list = Visit.objects.all()

    # Статистика по симптомам
    symptoms_count = visits_list.values('symptoms').annotate(count=Count('symptoms')).order_by('-count')

    # Выводим на консоль для отладки, что мы получаем в symptoms_count
    print("Symptoms Count (raw):", symptoms_count)

    # Получаем все симптомы по ID из symptoms_count
    symptom_ids = [item['symptoms'] for item in symptoms_count]
    symptoms = Symptom.objects.filter(id__in=symptom_ids)

    # Выводим на консоль, чтобы проверить, что мы получаем от фильтрации
    print("Symptoms Names:", [symptom.name for symptom in symptoms])

    # Статистика по диагнозам
    diagnosis_count = visits_list.values('diagnosis').annotate(count=Count('diagnosis')).order_by('-count')

    # Статистика по дате посещений
    date_visit_count = visits_list.values('visit_date__date').annotate(count=Count('visit_date')).order_by('visit_date__date')

    # Передаем данные в шаблон
    return render(request, 'analytics/patient_statistics.html', {
        'total_patients': total_patients,
        'age_groups': age_groups,
        'gender_distribution': gender_distribution,
        'visits_count': visits_list.count(),
        'symptoms_count': symptoms_count,
        'symptoms': symptoms,  # Передаем симптомы с их названиями
        'diagnosis_count': diagnosis_count,
        'date_visit_count': date_visit_count,
    })





def export_patient_statistics(request):
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="patient_statistics.csv"'

    response.charset = 'utf-8-sig'

    writer = csv.writer(response, delimiter=';', quoting=csv.QUOTE_MINIMAL)

    writer.writerow(['Имя', 'Фамилия', 'Отчество', 'Дата рождения', 'Пол', 'Возраст'])

    patients = Patient.objects.all()
    for patient in patients:
        writer.writerow([patient.first_name, patient.last_name, patient.middle_name, patient.date_of_birth,
                         patient.get_gender_display(), patient.age])

    return response

